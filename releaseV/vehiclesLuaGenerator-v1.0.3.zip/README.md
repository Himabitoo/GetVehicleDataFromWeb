# getVehicleDataFromWeb
gtaの車両情報の取得ツール。

## 取得できる値
・車の名前

・クラス(車種)

・price

・MODEL ID

・Top Speed

・前輪後輪

## Language && Packages
Python 3.10

Selenium

## Credit

github/Himabitoo
